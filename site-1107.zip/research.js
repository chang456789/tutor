// Hover crosshair + tooltip for inline SVG line charts on /research
document.querySelectorAll('script.vizdata').forEach((tag) => {
  const d = JSON.parse(tag.textContent);
  const svg = document.querySelector(`svg[data-chart="${tag.dataset.for}"]`);
  if (!svg) return;
  const fig = svg.closest('.tx-fig');
  const tip = document.createElement('div');
  tip.className = 'viz-tip'; tip.hidden = true; fig.appendChild(tip);
  const xh = svg.querySelector('.xh'), hit = svg.querySelector('.hit');
  const n = d.x.length;
  const show = (clientX) => {
    const r = svg.getBoundingClientRect();
    const vx = (clientX - r.left) / r.width * d.W;
    let i = Math.round((vx - d.L) / d.pw * (n - 1));
    i = Math.max(0, Math.min(n - 1, i));
    const px = d.L + i / (n - 1) * d.pw;
    xh.setAttribute('x1', px); xh.setAttribute('x2', px); xh.style.display = '';
    let h = `<b>${d.xl.split('（')[0]}：${d.x[i]}</b>`;
    for (const [k, v] of Object.entries(d.s)) h += `<span><i style="background:${d.c[k]}"></i>${k}　${v[i]} ${d.unit}</span>`;
    tip.innerHTML = h; tip.hidden = false;
    const fr = fig.getBoundingClientRect();
    let left = (px / d.W) * r.width + (r.left - fr.left) + 12;
    if (left + tip.offsetWidth > fr.width) left -= tip.offsetWidth + 24;
    tip.style.left = Math.max(0, left) + 'px';
    tip.style.top = (r.top - fr.top + 8) + 'px';
  };
  const hide = () => { tip.hidden = true; xh.style.display = 'none'; };
  hit.addEventListener('pointermove', (e) => show(e.clientX));
  hit.addEventListener('pointerdown', (e) => show(e.clientX));
  hit.addEventListener('pointerleave', hide);
});
