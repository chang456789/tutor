// Tutor Eric Taipei 學生專區共用程式
import { createClient } from "/student/supabase.min.js?v=2.118";

export const SUPABASE_URL = "https://xdmcrgohhivfvyhamxvu.supabase.co";
export const SUPABASE_KEY = "sb_publishable__O1RJmyDnHLjN8ozhLnKfg_lTzKuj9S";
export const ADMIN_FN = `${SUPABASE_URL}/functions/v1/student-admin`;
export const EMAIL_DOMAIN = "student.tutoreric.tw";

export const sb = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, storageKey: "te-student-auth" },
});

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

export function toEmail(account) {
  const a = String(account).trim().toLowerCase();
  return a.includes("@") ? a : `${a}@${EMAIL_DOMAIN}`;
}

/** 取得登入身分；未登入回傳 null */
export async function getMember() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return null;
  const uid = session.user.id;
  const [{ data: stu }, { data: adm }] = await Promise.all([
    sb.from("sz_students").select("username, display_name").eq("user_id", uid).maybeSingle(),
    sb.from("sz_admins").select("user_id").eq("user_id", uid).maybeSingle(),
  ]);
  const meta = session.user.user_metadata || {};
  return {
    session, uid,
    isAdmin: !!adm,
    isMember: !!adm || !!stu,
    username: stu?.username || meta.username || session.user.email.split("@")[0],
    name: stu?.display_name || meta.display_name || stu?.username || meta.username || "同學",
  };
}

/** 內頁使用：沒登入就導回登入頁 */
export async function requireMember() {
  const m = await getMember();
  if (!m || !m.isMember) {
    const back = encodeURIComponent(location.pathname + location.search);
    location.replace(`/student/?next=${back}`);
    return new Promise(() => {});
  }
  renderUserBar(m);
  return m;
}

export function renderUserBar(m) {
  const bar = $("#sz-userbar");
  if (!bar) return;
  bar.innerHTML = `
    <span class="sz-hello">👋 ${esc(m.name)}${m.isAdmin ? '<span class="sz-badge">管理者</span>' : ""}</span>
    <nav class="sz-tabs" aria-label="學生專區選單">
      <a href="/student/">專區首頁</a>
      <a href="/student/news/">國際新聞</a>
      <a href="/student/vocab/">每週單字</a>
      <a href="/student/units/">考試重點</a>
      ${m.isAdmin ? '<a href="/student/admin/">帳號管理</a>' : ""}
    </nav>
    <button type="button" class="sz-linkbtn" id="sz-logout">登出</button>`;
  $$(".sz-tabs a", bar).forEach((a) => {
    const p = a.getAttribute("href");
    if (p === "/student/" ? location.pathname === "/student/" : location.pathname.startsWith(p)) a.setAttribute("aria-current", "page");
  });
  $("#sz-logout", bar).addEventListener("click", async () => {
    await sb.auth.signOut();
    location.href = "/student/";
  });
  bar.hidden = false;
}

export function fmtWeek(d) {
  const s = new Date(d + "T00:00:00");
  const e = new Date(s); e.setDate(s.getDate() + 6);
  const f = (x) => `${x.getMonth() + 1}/${x.getDate()}`;
  return `${s.getFullYear()} 年 ${f(s)}–${f(e)}`;
}

export function speak(text, rate = 0.9) {
  if (!("speechSynthesis" in window)) return false;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-US"; u.rate = rate;
  speechSynthesis.speak(u);
  return true;
}

export function showError(el, msg) {
  el.innerHTML = `<div class="sz-alert">${esc(msg)}</div>`;
}

export function store(key, val) {
  try {
    if (val === undefined) return localStorage.getItem(key);
    localStorage.setItem(key, val);
  } catch { return null; }
}
