import { n as val, t as wireForm } from "/_astro/forms.DaF1zlyh.js";

const form = document.getElementById("join-form");

wireForm(form, {
  type: "contact",
  validate: () => {
    if (!form.querySelector('input[name="subj"]:checked')) return "請至少勾選一個可教科目。";
    return null;
  },
  collect: (fd) => {
    const subjects = fd.getAll("subj").join("、");
    const lines = [
      "【加入團隊報名】",
      "學校科系年級：" + val(fd, "school"),
      "可教科目：" + subjects,
      val(fd, "subjNote") ? "科目補充：" + val(fd, "subjNote") : "",
      "可上課時段：" + val(fd, "time"),
      val(fd, "cred") ? "成績／證照：" + val(fd, "cred") : "",
      val(fd, "exp") ? "教學經驗：" + val(fd, "exp") : "",
      "自我介紹：" + val(fd, "intro"),
    ].filter(Boolean);
    return {
      name: val(fd, "name"),
      email: val(fd, "email"),
      phone: val(fd, "phone"),
      topic: "加入團隊（合作老師報名）",
      message: lines.join("\n"),
    };
  },
  onSuccess: (res) => {
    form.hidden = true;
    const done = document.getElementById("join-done");
    done.hidden = false;
    if (res.demo) document.getElementById("join-demo").hidden = false;
    done.focus();
  },
});
