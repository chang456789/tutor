// Tutor Eric Taipei｜最新教育消息（首頁模組與歷史文章頁共用）
const URL_ = "https://xdmcrgohhivfvyhamxvu.supabase.co/rest/v1/edu_news";
const KEY = "sb_publishable__O1RJmyDnHLjN8ozhLnKfg_lTzKuj9S";
const TABS = [
  { id: "all", label: "全部" },
  { id: "official", label: "官方與權威發布", cats: ["教育部公告", "會考與升學", "大考趨勢"] },
  { id: "analysis", label: "名師分析", cats: ["名師猜題", "命題趨勢"] },
  { id: "subject", label: "學級 × 學科" },
  { id: "vocational", label: "高職與技職", cats: ["技職升學"] },
];
const ALL_CATS = ["教育部公告", "會考與升學", "大考趨勢", "名師猜題", "命題趨勢", "學科新聞", "技職升學"];
const LEVELS = ["國小", "國中", "高中", "高職"];
const SUBJECTS = ["國文", "數學", "英文", "社會", "自然"];
const PAGE = 8;

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (d) => d.replaceAll("-", ".");

async function fetchNews({ sinceDays } = {}) {
  const p = new URLSearchParams({ select: "*", order: "published_at.desc,id.desc", limit: "1000" });
  if (sinceDays) {
    const d = new Date(Date.now() - sinceDays * 864e5 + 8 * 3600e3).toISOString().slice(0, 10);
    p.set("published_at", `gte.${d}`);
  }
  const r = await fetch(`${URL_}?${p}`, { headers: { apikey: KEY, Authorization: `Bearer ${KEY}` } });
  if (!r.ok) throw new Error(`讀取失敗（${r.status}）`);
  return r.json();
}

export async function mountEduNews(root, { mode = "home" } = {}) {
  const home = mode === "home";
  const st = { tab: "all", cat: "", levels: new Set(), subjects: new Set(), q: "", shown: home ? PAGE : PAGE * 2 };
  const q0 = new URLSearchParams(location.search);
  if (!home && q0.get("tab") && TABS.some((t) => t.id === q0.get("tab"))) st.tab = q0.get("tab");

  root.innerHTML = `
    <div class="en-tabs" role="tablist" aria-label="新聞分類">
      ${TABS.map((t) => `<button type="button" role="tab" data-tab="${t.id}" aria-selected="${t.id === st.tab}">${t.label}</button>`).join("")}
    </div>
    <div class="en-filters">
      ${home ? "" : `<label class="en-search"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input type="search" id="en-q" placeholder="搜尋標題、內容或標籤（例如：會考、雙語、學測）" aria-label="搜尋歷史文章"></label>`}
      <label class="en-select"><span>分類</span><select id="en-cat" aria-label="分類"></select></label>
      <div class="en-chipset" role="group" aria-label="學級（可複選）"><span>學級</span>${LEVELS.map((l) => `<button type="button" class="en-chip" data-level="${l}" aria-pressed="false">${l}</button>`).join("")}</div>
      <div class="en-chipset" role="group" aria-label="科目（可複選）"><span>科目</span>${SUBJECTS.map((s) => `<button type="button" class="en-chip" data-subject="${s}" aria-pressed="false">${s}</button>`).join("")}</div>
      <button type="button" class="en-reset" id="en-reset" hidden>清除篩選</button>
    </div>
    <div class="te-news en-list" id="en-list" aria-live="polite"><div class="en-empty">載入中…</div></div>
    <div class="en-foot" id="en-foot"></div>`;

  const $ = (s) => root.querySelector(s);
  let data = [];
  try { data = await fetchNews({ sinceDays: home ? 30 : 0 }); }
  catch { $("#en-list").innerHTML = `<div class="en-empty">消息暫時無法載入，請稍後再試。</div>`; return; }

  function drawCats() {
    const t = TABS.find((x) => x.id === st.tab);
    const cats = t.cats || (t.id === "subject" ? ["學科新聞"] : ALL_CATS);
    if (!cats.includes(st.cat)) st.cat = "";
    $("#en-cat").innerHTML = `<option value="">全部分類</option>` + cats.map((c) => `<option ${c === st.cat ? "selected" : ""}>${c}</option>`).join("");
  }
  function match(n) {
    if (st.tab !== "all" && st.tab !== "subject" && n.section !== st.tab) return false;
    if (st.tab === "subject" && !(n.section === "subject" || n.subjects.length)) return false;
    if (st.cat && n.category !== st.cat) return false;
    if (st.levels.size && !n.levels.some((l) => st.levels.has(l))) return false;
    if (st.subjects.size && !n.subjects.some((s) => st.subjects.has(s))) return false;
    if (st.q) {
      const hay = (n.title + n.summary + n.tags.join(" ") + n.levels.join(" ") + n.subjects.join(" ") + n.category).toLowerCase();
      if (!st.q.toLowerCase().split(/\s+/).every((w) => hay.includes(w))) return false;
    }
    return true;
  }
  function row(n) {
    const tags = [...n.levels, ...n.subjects, ...n.tags].filter((v, i, a) => a.indexOf(v) === i);
    return `<a class="te-news-row en-row" href="${esc(n.source_url)}" target="_blank" rel="noopener">
      <span class="te-news-date">${fmt(n.published_at)}</span>
      <span class="te-news-cat">${esc(n.category)}</span>
      <span class="en-body">
        <span class="te-news-title">${esc(n.title)}${n.is_hot ? '<span class="te-hot">HOT</span>' : ""}</span>
        <span class="en-sum">${esc(n.summary)}</span>
        <span class="en-meta"><span class="en-tags">${tags.slice(0, 6).map((t) => `#${esc(t)}`).join(" ")}</span><span class="en-src">來源：${esc(n.source_name)} ↗</span></span>
      </span>
      <span class="te-arrow" aria-hidden="true">→</span></a>`;
  }
  function render() {
    const rows = data.filter(match);
    const shown = rows.slice(0, st.shown);
    const filtered = st.tab !== "all" || st.cat || st.levels.size || st.subjects.size || st.q;
    $("#en-reset").hidden = !filtered;
    $("#en-list").innerHTML = `<div class="te-news-head" aria-hidden="true"><span>日期</span><span>分類</span><span>標題</span><span></span></div>` +
      (shown.map(row).join("") || `<div class="en-empty">${home ? "近 30 天內沒有符合條件的消息。" : "找不到符合條件的文章。"}${home ? ` <a href="/news/">到歷史文章搜尋看看</a>` : ""}</div>`);
    $("#en-foot").innerHTML = `
      ${rows.length > shown.length ? `<button type="button" class="en-more" id="en-more">載入更多（還有 ${rows.length - shown.length} 則）</button>` : ""}
      ${home ? `<a class="te-more" href="/news/">歷史文章搜尋 →</a>` : `<span class="en-count">共 ${rows.length} 則</span>`}
      <span class="en-note">內容經篩選，只收錄政策宣導、升學指引、命題趨勢、優秀教學案例等正向或客觀新聞；點標題可閱讀原始報導。</span>`;
    $("#en-more")?.addEventListener("click", () => { st.shown += PAGE; render(); });
  }
  root.querySelectorAll("[data-tab]").forEach((b) => b.addEventListener("click", () => {
    st.tab = b.dataset.tab; st.shown = home ? PAGE : PAGE * 2;
    root.querySelectorAll("[data-tab]").forEach((x) => x.setAttribute("aria-selected", x === b));
    drawCats(); render();
  }));
  $("#en-cat").addEventListener("change", (e) => { st.cat = e.target.value; render(); });
  root.querySelectorAll("[data-level]").forEach((b) => b.addEventListener("click", () => {
    const v = b.dataset.level; st.levels.has(v) ? st.levels.delete(v) : st.levels.add(v);
    b.setAttribute("aria-pressed", st.levels.has(v)); render();
  }));
  root.querySelectorAll("[data-subject]").forEach((b) => b.addEventListener("click", () => {
    const v = b.dataset.subject; st.subjects.has(v) ? st.subjects.delete(v) : st.subjects.add(v);
    b.setAttribute("aria-pressed", st.subjects.has(v)); render();
  }));
  $("#en-reset").addEventListener("click", () => {
    st.tab = "all"; st.cat = ""; st.levels.clear(); st.subjects.clear(); st.q = "";
    root.querySelectorAll("[data-tab]").forEach((x) => x.setAttribute("aria-selected", x.dataset.tab === "all"));
    root.querySelectorAll(".en-chip").forEach((x) => x.setAttribute("aria-pressed", "false"));
    const qi = $("#en-q"); if (qi) qi.value = "";
    drawCats(); render();
  });
  let t; $("#en-q")?.addEventListener("input", (e) => { clearTimeout(t); t = setTimeout(() => { st.q = e.target.value.trim(); render(); }, 200); });
  drawCats(); render();
}
